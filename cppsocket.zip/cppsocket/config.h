/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "cppsocket"

/* Version number of package */
#define VERSION "0.8.4"

/* C++ compiler supports template repository */
#define HAVE_TEMPLATE_REPOSITORY 1

