g++ -L /usr/local/lib/ -lcppsocket test-client.cpp -o test-client
