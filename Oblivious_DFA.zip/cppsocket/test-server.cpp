#include <iostream>
#include <cppsocket/tcpserver.h>
#include <cppsocket/socket.h>
#include <cppsocket/stringbuffer.h>
	
using namespace std;

int main()
{
 try
 {
   CPPSocket::Socket server;
   CPPSocket::Address address(CPPSocket::Address::ANY_IP, 1234, false);

   server.open(CPPSocket::Socket::TCP);

   server.setsockopt(CPPSocket::SocketOption::ReuseAddr(1));

   server.bind(address);

   server.listen(5);

   CPPSocket::Address clientAddress;
   CPPSocket::Socket connection = server.accept(clientAddress);

   CPPSocket::StringBuffer data(1024);
   CPPSocket::StringBuffer data2("Dim diri dirim dirim dim!\n");

   connection.recv(data);

   clientAddress.lookup();

   cout << "Receive data from " << clientAddress.getName();
   cout << " on port " << clientAddress.getPort() << endl;
   cout << string(data) << endl;

   connection.send(data2);

   connection.close();

   server.close();
 }
 catch(CPPSocket::Exception & error)
 {
   cerr << error.getMessage() << endl;

   return EXIT_FAILURE;
 }

 return EXIT_SUCCESS;
}
