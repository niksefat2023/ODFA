g++ -L /usr/local/lib/ -lcppsocket hr_time.cpp EC_Naor_OT.cpp  cryptopp.cpp Experiments.cpp OAE.cpp DFA.cpp cryptopp-lib/*.o -o cryptopp
