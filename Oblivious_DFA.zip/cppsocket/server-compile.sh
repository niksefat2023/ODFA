g++ -L /usr/local/lib/ -lcppsocket test-server.cpp -o test-server
