#include <iostream>
#include <cppsocket/tcpserver.h>
#include <cppsocket/socket.h>
#include <cppsocket/stringbuffer.h>
	
using namespace std;


int main(int argc, char *argv[])
{
try
{
if(argc != 2)
{
 throw CPPSocket::Exception("main()", "Only one argument allowed.", 0);
}

CPPSocket::Socket client;
CPPSocket::Address serverAddress(argv[1], 1234);

client.open(CPPSocket::Socket::TCP);

client.connect(serverAddress);

CPPSocket::StringBuffer data("Hello, World!\n");

client.send(data);

CPPSocket::StringBuffer recvData(1024);

client.recv(recvData);
cout << string(recvData) << endl;

client.close();
}
catch(CPPSocket::Exception & error)
{
cerr << error.getMessage() << endl;

return EXIT_FAILURE;
}

return EXIT_SUCCESS;
}
