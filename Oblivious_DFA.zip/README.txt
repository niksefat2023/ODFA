Oblivious DFA Code By:
Saeed Sadeghian (sadeghis@gmail.com)
Salman Niksefat (niksefat@aut.ac.ir)


run test-ot-compile.sh to compile the code (local version)
run final_oae_256_net_compile.sh to compile the network version of the code.